"use client";

import { useState } from "react";
import { TrendingUp, Scale, Plane, DollarSign, Gem, Tag } from "lucide-react";

type CalculatorTab =
  | "profit-margin"
  | "break-even"
  | "runway"
  | "cash-flow"
  | "valuation"
  | "pricing";

export default function BusinessCalculators() {
  const [activeTab, setActiveTab] = useState<CalculatorTab>("profit-margin");

  const tabs = [
    { id: "profit-margin" as CalculatorTab, label: "Profit Margin", Icon: TrendingUp },
    { id: "break-even" as CalculatorTab, label: "Break-Even", Icon: Scale },
    { id: "runway" as CalculatorTab, label: "Runway", Icon: Plane },
    { id: "cash-flow" as CalculatorTab, label: "Cash Flow", Icon: DollarSign },
    { id: "valuation" as CalculatorTab, label: "Valuation", Icon: Gem },
    { id: "pricing" as CalculatorTab, label: "Pricing", Icon: Tag },
  ];

  return (
    <div className="max-w-5xl mx-auto p-4 sm:p-6">
      {/* Tabs */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 mb-6 overflow-x-auto">
        <div className="flex min-w-max sm:min-w-0">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex-1 px-3 sm:px-6 py-3 sm:py-4 text-xs sm:text-sm font-medium transition-colors whitespace-nowrap flex items-center justify-center gap-2 ${
                activeTab === tab.id
                  ? "bg-blue-50 text-blue-700 border-b-2 border-blue-700"
                  : "text-gray-600 hover:text-gray-900 hover:bg-gray-50"
              }`}
            >
              <tab.Icon className="w-4 h-4" />
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Calculator Content */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 sm:p-6">
        {activeTab === "profit-margin" && <ProfitMarginCalculator />}
        {activeTab === "break-even" && <BreakEvenCalculator />}
        {activeTab === "runway" && <RunwayCalculator />}
        {activeTab === "cash-flow" && <CashFlowCalculator />}
        {activeTab === "valuation" && <ValuationCalculator />}
        {activeTab === "pricing" && <PricingCalculator />}
      </div>
    </div>
  );
}

// Profit Margin Calculator
function ProfitMarginCalculator() {
  const [revenue, setRevenue] = useState("");
  const [cogs, setCogs] = useState("");
  const [expenses, setExpenses] = useState("");

  const rev = parseFloat(revenue) || 0;
  const costs = parseFloat(cogs) || 0;
  const exp = parseFloat(expenses) || 0;

  const grossProfit = rev - costs;
  const grossMargin = rev > 0 ? (grossProfit / rev) * 100 : 0;
  const netProfit = grossProfit - exp;
  const netMargin = rev > 0 ? (netProfit / rev) * 100 : 0;

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-semibold text-gray-900">Profit Margin Calculator</h2>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Revenue ($)
          </label>
          <input
            type="number"
            value={revenue}
            onChange={(e) => setRevenue(e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="0.00"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Cost of Goods Sold ($)
          </label>
          <input
            type="number"
            value={cogs}
            onChange={(e) => setCogs(e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="0.00"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Operating Expenses ($)
          </label>
          <input
            type="number"
            value={expenses}
            onChange={(e) => setExpenses(e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="0.00"
          />
        </div>
      </div>

      {rev > 0 && (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-6">
          <div className="bg-blue-50 rounded-lg p-4 border border-blue-200">
            <div className="text-sm font-medium text-blue-900 mb-1">Gross Profit Margin</div>
            <div className="text-3xl font-bold text-blue-700">{grossMargin.toFixed(1)}%</div>
            <div className="text-sm text-blue-600 mt-1">
              ${grossProfit.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} gross profit
            </div>
          </div>

          <div className={`rounded-lg p-4 border ${netProfit >= 0 ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200'}`}>
            <div className={`text-sm font-medium mb-1 ${netProfit >= 0 ? 'text-green-900' : 'text-red-900'}`}>
              Net Profit Margin
            </div>
            <div className={`text-3xl font-bold ${netProfit >= 0 ? 'text-green-700' : 'text-red-700'}`}>
              {netMargin.toFixed(1)}%
            </div>
            <div className={`text-sm mt-1 ${netProfit >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              ${netProfit.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} net profit
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// Break-Even Calculator
function BreakEvenCalculator() {
  const [fixedCosts, setFixedCosts] = useState("");
  const [pricePerUnit, setPricePerUnit] = useState("");
  const [variableCostPerUnit, setVariableCostPerUnit] = useState("");

  const fixed = parseFloat(fixedCosts) || 0;
  const price = parseFloat(pricePerUnit) || 0;
  const variable = parseFloat(variableCostPerUnit) || 0;

  const contributionMargin = price - variable;
  const breakEvenUnits = contributionMargin > 0 ? fixed / contributionMargin : 0;
  const breakEvenRevenue = breakEvenUnits * price;

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-semibold text-gray-900">Break-Even Point Calculator</h2>
      <p className="text-sm text-gray-600">Calculate when your business becomes profitable</p>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Fixed Costs ($)
          </label>
          <input
            type="number"
            value={fixedCosts}
            onChange={(e) => setFixedCosts(e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="0.00"
          />
          <p className="text-xs text-gray-500 mt-1">Rent, salaries, insurance</p>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Price per Unit ($)
          </label>
          <input
            type="number"
            value={pricePerUnit}
            onChange={(e) => setPricePerUnit(e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="0.00"
          />
          <p className="text-xs text-gray-500 mt-1">Selling price</p>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Variable Cost per Unit ($)
          </label>
          <input
            type="number"
            value={variableCostPerUnit}
            onChange={(e) => setVariableCostPerUnit(e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="0.00"
          />
          <p className="text-xs text-gray-500 mt-1">Materials, labor per unit</p>
        </div>
      </div>

      {contributionMargin > 0 && breakEvenUnits > 0 && (
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-6">
          <div className="bg-purple-50 rounded-lg p-4 border border-purple-200">
            <div className="text-sm font-medium text-purple-900 mb-1">Break-Even Units</div>
            <div className="text-3xl font-bold text-purple-700">
              {Math.ceil(breakEvenUnits).toLocaleString()}
            </div>
            <div className="text-sm text-purple-600 mt-1">units to sell</div>
          </div>

          <div className="bg-purple-50 rounded-lg p-4 border border-purple-200">
            <div className="text-sm font-medium text-purple-900 mb-1">Break-Even Revenue</div>
            <div className="text-3xl font-bold text-purple-700">
              ${breakEvenRevenue.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 })}
            </div>
            <div className="text-sm text-purple-600 mt-1">to be profitable</div>
          </div>

          <div className="bg-purple-50 rounded-lg p-4 border border-purple-200">
            <div className="text-sm font-medium text-purple-900 mb-1">Contribution Margin</div>
            <div className="text-3xl font-bold text-purple-700">
              ${contributionMargin.toFixed(2)}
            </div>
            <div className="text-sm text-purple-600 mt-1">per unit sold</div>
          </div>
        </div>
      )}
    </div>
  );
}

// Runway Calculator
function RunwayCalculator() {
  const [cashBalance, setCashBalance] = useState("");
  const [monthlyBurn, setMonthlyBurn] = useState("");
  const [monthlyRevenue, setMonthlyRevenue] = useState("");

  const balance = parseFloat(cashBalance) || 0;
  const burn = parseFloat(monthlyBurn) || 0;
  const revenue = parseFloat(monthlyRevenue) || 0;

  const netBurn = burn - revenue;
  const runwayMonths = netBurn > 0 ? balance / netBurn : 0;

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-semibold text-gray-900">Runway Calculator</h2>
      <p className="text-sm text-gray-600">How long until you run out of money?</p>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Current Cash Balance ($)
          </label>
          <input
            type="number"
            value={cashBalance}
            onChange={(e) => setCashBalance(e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="0.00"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Monthly Burn Rate ($)
          </label>
          <input
            type="number"
            value={monthlyBurn}
            onChange={(e) => setMonthlyBurn(e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="0.00"
          />
          <p className="text-xs text-gray-500 mt-1">Monthly expenses</p>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Monthly Revenue ($)
          </label>
          <input
            type="number"
            value={monthlyRevenue}
            onChange={(e) => setMonthlyRevenue(e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="0.00"
          />
        </div>
      </div>

      {balance > 0 && netBurn > 0 && (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-6">
          <div className={`rounded-lg p-4 border ${
            runwayMonths > 12 ? 'bg-green-50 border-green-200' :
            runwayMonths > 6 ? 'bg-yellow-50 border-yellow-200' :
            'bg-red-50 border-red-200'
          }`}>
            <div className={`text-sm font-medium mb-1 ${
              runwayMonths > 12 ? 'text-green-900' :
              runwayMonths > 6 ? 'text-yellow-900' :
              'text-red-900'
            }`}>
              Runway
            </div>
            <div className={`text-3xl font-bold ${
              runwayMonths > 12 ? 'text-green-700' :
              runwayMonths > 6 ? 'text-yellow-700' :
              'text-red-700'
            }`}>
              {runwayMonths.toFixed(1)} months
            </div>
            <div className={`text-sm mt-1 ${
              runwayMonths > 12 ? 'text-green-600' :
              runwayMonths > 6 ? 'text-yellow-600' :
              'text-red-600'
            }`}>
              {runwayMonths > 12 ? 'Healthy runway' : runwayMonths > 6 ? 'Consider fundraising' : 'Critical - act now!'}
            </div>
          </div>

          <div className="bg-gray-50 rounded-lg p-4 border border-gray-200">
            <div className="text-sm font-medium text-gray-900 mb-1">Net Monthly Burn</div>
            <div className="text-3xl font-bold text-gray-700">
              ${netBurn.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 })}
            </div>
            <div className="text-sm text-gray-600 mt-1">
              After revenue
            </div>
          </div>
        </div>
      )}

      {netBurn <= 0 && revenue > 0 && (
        <div className="bg-green-50 rounded-lg p-4 border border-green-200 mt-6">
          <div className="text-green-900 font-medium">Cash Flow Positive!</div>
          <div className="text-sm text-green-700 mt-1">
            Your revenue exceeds your burn rate. Keep it up!
          </div>
        </div>
      )}
    </div>
  );
}

// Cash Flow Projector
function CashFlowCalculator() {
  const [startingCash, setStartingCash] = useState("");
  const [monthlyRevenue, setMonthlyRevenue] = useState("");
  const [monthlyExpenses, setMonthlyExpenses] = useState("");
  const [growthRate, setGrowthRate] = useState("0");

  const starting = parseFloat(startingCash) || 0;
  const revenue = parseFloat(monthlyRevenue) || 0;
  const expenses = parseFloat(monthlyExpenses) || 0;
  const growth = parseFloat(growthRate) || 0;

  const projections = [];
  let currentCash = starting;
  let currentRevenue = revenue;

  for (let month = 1; month <= 12; month++) {
    const netCashFlow = currentRevenue - expenses;
    currentCash += netCashFlow;

    projections.push({
      month,
      revenue: currentRevenue,
      expenses,
      netCashFlow,
      endingBalance: currentCash,
    });

    currentRevenue *= (1 + growth / 100);
  }

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-semibold text-gray-900">Cash Flow Projector</h2>
      <p className="text-sm text-gray-600">12-month cash flow projection</p>

      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Starting Cash ($)
          </label>
          <input
            type="number"
            value={startingCash}
            onChange={(e) => setStartingCash(e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="0.00"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Monthly Revenue ($)
          </label>
          <input
            type="number"
            value={monthlyRevenue}
            onChange={(e) => setMonthlyRevenue(e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="0.00"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Monthly Expenses ($)
          </label>
          <input
            type="number"
            value={monthlyExpenses}
            onChange={(e) => setMonthlyExpenses(e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="0.00"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Monthly Growth (%)
          </label>
          <input
            type="number"
            value={growthRate}
            onChange={(e) => setGrowthRate(e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="0"
            step="0.1"
          />
        </div>
      </div>

      {starting > 0 && (
        <div className="mt-6 overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-gray-200 bg-gray-50">
                <th className="text-left py-3 px-4 font-medium text-gray-700">Month</th>
                <th className="text-right py-3 px-4 font-medium text-gray-700">Revenue</th>
                <th className="text-right py-3 px-4 font-medium text-gray-700">Expenses</th>
                <th className="text-right py-3 px-4 font-medium text-gray-700">Net Cash Flow</th>
                <th className="text-right py-3 px-4 font-medium text-gray-700">Ending Balance</th>
              </tr>
            </thead>
            <tbody>
              {projections.map((p) => (
                <tr key={p.month} className="border-b border-gray-100 hover:bg-gray-50">
                  <td className="py-3 px-4 font-medium text-gray-900">Month {p.month}</td>
                  <td className="py-3 px-4 text-right text-gray-700">
                    ${p.revenue.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 })}
                  </td>
                  <td className="py-3 px-4 text-right text-gray-700">
                    ${p.expenses.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 })}
                  </td>
                  <td className={`py-3 px-4 text-right font-medium ${p.netCashFlow >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                    ${p.netCashFlow.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 })}
                  </td>
                  <td className={`py-3 px-4 text-right font-medium ${p.endingBalance >= 0 ? 'text-gray-900' : 'text-red-600'}`}>
                    ${p.endingBalance.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 })}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

// Business Valuation Estimator
function ValuationCalculator() {
  const [annualRevenue, setAnnualRevenue] = useState("");
  const [annualProfit, setAnnualProfit] = useState("");
  const [growthRate, setGrowthRate] = useState("");
  const [industry, setIndustry] = useState("saas");

  const revenue = parseFloat(annualRevenue) || 0;
  const profit = parseFloat(annualProfit) || 0;
  const growth = parseFloat(growthRate) || 0;

  // Industry-specific multiples
  const multiples: Record<string, { revenue: number; profit: number }> = {
    saas: { revenue: 8, profit: 15 },
    ecommerce: { revenue: 1.5, profit: 3 },
    service: { revenue: 1, profit: 3 },
    manufacturing: { revenue: 0.75, profit: 4 },
    retail: { revenue: 0.5, profit: 2.5 },
  };

  const multiple = multiples[industry];
  const baseRevenueValuation = revenue * multiple.revenue;
  const baseProfitValuation = profit * multiple.profit;

  // Growth adjustment (add 0-50% based on growth rate)
  const growthMultiplier = 1 + Math.min(growth / 100, 0.5);
  const revenueValuation = baseRevenueValuation * growthMultiplier;
  const profitValuation = baseProfitValuation * growthMultiplier;
  const averageValuation = (revenueValuation + profitValuation) / 2;

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-semibold text-gray-900">Business Valuation Estimator</h2>
      <p className="text-sm text-gray-600">Estimate your company's worth using industry multiples</p>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Annual Revenue ($)
          </label>
          <input
            type="number"
            value={annualRevenue}
            onChange={(e) => setAnnualRevenue(e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="0.00"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Annual Net Profit ($)
          </label>
          <input
            type="number"
            value={annualProfit}
            onChange={(e) => setAnnualProfit(e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="0.00"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Industry
          </label>
          <select
            value={industry}
            onChange={(e) => setIndustry(e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="saas">SaaS (Software)</option>
            <option value="ecommerce">E-commerce</option>
            <option value="service">Service Business</option>
            <option value="manufacturing">Manufacturing</option>
            <option value="retail">Retail</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            YoY Growth Rate (%)
          </label>
          <input
            type="number"
            value={growthRate}
            onChange={(e) => setGrowthRate(e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="0"
          />
        </div>
      </div>

      {revenue > 0 && profit > 0 && (
        <div className="space-y-4 mt-6">
          <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg p-6 border border-blue-200">
            <div className="text-sm font-medium text-gray-900 mb-2">Estimated Valuation Range</div>
            <div className="text-4xl font-bold text-gray-900 mb-2">
              ${Math.min(revenueValuation, profitValuation).toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 })}
              {' - '}
              ${Math.max(revenueValuation, profitValuation).toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 })}
            </div>
            <div className="text-sm text-gray-600">
              Average: ${averageValuation.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 })}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="bg-white rounded-lg p-4 border border-gray-200">
              <div className="text-sm font-medium text-gray-700 mb-1">Revenue Multiple</div>
              <div className="text-2xl font-bold text-gray-900">
                {multiple.revenue}x
              </div>
              <div className="text-sm text-gray-600 mt-1">
                Valuation: ${revenueValuation.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 })}
              </div>
            </div>

            <div className="bg-white rounded-lg p-4 border border-gray-200">
              <div className="text-sm font-medium text-gray-700 mb-1">Profit Multiple (EBITDA)</div>
              <div className="text-2xl font-bold text-gray-900">
                {multiple.profit}x
              </div>
              <div className="text-sm text-gray-600 mt-1">
                Valuation: ${profitValuation.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 })}
              </div>
            </div>
          </div>

          <div className="bg-blue-50 rounded-lg p-4 border border-blue-200 text-sm text-blue-900">
            <strong>Note:</strong> This is a simplified estimate. Actual valuations depend on many factors including market conditions, assets, competitive advantages, customer retention, and more. Consult a professional for accurate valuation.
          </div>
        </div>
      )}
    </div>
  );
}

// Pricing Strategy Calculator
function PricingCalculator() {
  const [costPerUnit, setCostPerUnit] = useState("");
  const [desiredMargin, setDesiredMargin] = useState("40");
  const [monthlyVolume, setMonthlyVolume] = useState("");
  const [competitorPrice, setCompetitorPrice] = useState("");

  const cost = parseFloat(costPerUnit) || 0;
  const margin = parseFloat(desiredMargin) || 0;
  const volume = parseFloat(monthlyVolume) || 0;
  const competitor = parseFloat(competitorPrice) || 0;

  // Cost-plus pricing
  const costPlusPrice = cost > 0 ? cost / (1 - margin / 100) : 0;

  // Value-based pricing (assuming competitor pricing is market value)
  const valuePriceDiscount = competitor * 0.9; // 10% below competitor
  const valuePriceMatch = competitor;
  const valuePricePremium = competitor * 1.1; // 10% above competitor

  const monthlyRevenueCostPlus = costPlusPrice * volume;
  const monthlyProfitCostPlus = (costPlusPrice - cost) * volume;

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-semibold text-gray-900">Pricing Strategy Calculator</h2>
      <p className="text-sm text-gray-600">Find the optimal price for your product or service</p>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Cost per Unit ($)
          </label>
          <input
            type="number"
            value={costPerUnit}
            onChange={(e) => setCostPerUnit(e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="0.00"
          />
          <p className="text-xs text-gray-500 mt-1">Total cost to produce/deliver</p>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Desired Margin (%)
          </label>
          <input
            type="number"
            value={desiredMargin}
            onChange={(e) => setDesiredMargin(e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="40"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Expected Monthly Volume
          </label>
          <input
            type="number"
            value={monthlyVolume}
            onChange={(e) => setMonthlyVolume(e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="0"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Competitor Price ($)
          </label>
          <input
            type="number"
            value={competitorPrice}
            onChange={(e) => setCompetitorPrice(e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="0.00"
          />
          <p className="text-xs text-gray-500 mt-1">Optional: for comparison</p>
        </div>
      </div>

      {cost > 0 && (
        <div className="space-y-4 mt-6">
          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-3">Cost-Plus Pricing</h3>
            <div className="bg-blue-50 rounded-lg p-6 border border-blue-200">
              <div className="text-sm font-medium text-blue-900 mb-2">Recommended Price</div>
              <div className="text-4xl font-bold text-blue-700 mb-4">
                ${costPlusPrice.toFixed(2)}
              </div>

              {volume > 0 && (
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <div className="text-blue-900 font-medium">Monthly Revenue</div>
                    <div className="text-blue-700 text-lg font-semibold">
                      ${monthlyRevenueCostPlus.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 })}
                    </div>
                  </div>
                  <div>
                    <div className="text-blue-900 font-medium">Monthly Profit</div>
                    <div className="text-blue-700 text-lg font-semibold">
                      ${monthlyProfitCostPlus.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 })}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>

          {competitor > 0 && (
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Competitive Pricing Strategies</h3>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="bg-white rounded-lg p-4 border border-gray-200">
                  <div className="text-sm font-medium text-gray-900 mb-2">Penetration (Discount)</div>
                  <div className="text-2xl font-bold text-orange-600 mb-1">
                    ${valuePriceDiscount.toFixed(2)}
                  </div>
                  <div className="text-xs text-gray-600 mb-2">10% below competitor</div>
                  {cost > 0 && (
                    <div className="text-sm text-gray-700">
                      Margin: {(((valuePriceDiscount - cost) / valuePriceDiscount) * 100).toFixed(1)}%
                    </div>
                  )}
                </div>

                <div className="bg-white rounded-lg p-4 border border-gray-200">
                  <div className="text-sm font-medium text-gray-900 mb-2">Match Market</div>
                  <div className="text-2xl font-bold text-blue-600 mb-1">
                    ${valuePriceMatch.toFixed(2)}
                  </div>
                  <div className="text-xs text-gray-600 mb-2">Same as competitor</div>
                  {cost > 0 && (
                    <div className="text-sm text-gray-700">
                      Margin: {(((valuePriceMatch - cost) / valuePriceMatch) * 100).toFixed(1)}%
                    </div>
                  )}
                </div>

                <div className="bg-white rounded-lg p-4 border border-gray-200">
                  <div className="text-sm font-medium text-gray-900 mb-2">Premium</div>
                  <div className="text-2xl font-bold text-purple-600 mb-1">
                    ${valuePricePremium.toFixed(2)}
                  </div>
                  <div className="text-xs text-gray-600 mb-2">10% above competitor</div>
                  {cost > 0 && (
                    <div className="text-sm text-gray-700">
                      Margin: {(((valuePricePremium - cost) / valuePricePremium) * 100).toFixed(1)}%
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          <div className="bg-yellow-50 rounded-lg p-4 border border-yellow-200 text-sm text-yellow-900">
            <strong>Tips:</strong> Consider your value proposition, target market, and brand positioning. Premium pricing works with strong differentiation. Penetration pricing helps gain market share quickly.
          </div>
        </div>
      )}
    </div>
  );
}
