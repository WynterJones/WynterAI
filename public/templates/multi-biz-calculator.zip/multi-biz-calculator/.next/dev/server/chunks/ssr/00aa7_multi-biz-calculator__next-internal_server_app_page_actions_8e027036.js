module.exports = [
"[project]/v1-templates/multi-biz-calculator/.next-internal/server/app/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=00aa7_multi-biz-calculator__next-internal_server_app_page_actions_8e027036.js.map