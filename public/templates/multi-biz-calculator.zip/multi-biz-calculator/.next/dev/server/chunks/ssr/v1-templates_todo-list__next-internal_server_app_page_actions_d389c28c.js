module.exports = [
"[project]/v1-templates/todo-list/.next-internal/server/app/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=v1-templates_todo-list__next-internal_server_app_page_actions_d389c28c.js.map