module.exports = [
"[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>BusinessCalculators
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/v1-templates/multi-biz-calculator/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/v1-templates/multi-biz-calculator/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trending$2d$up$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__TrendingUp$3e$__ = __turbopack_context__.i("[project]/v1-templates/multi-biz-calculator/node_modules/lucide-react/dist/esm/icons/trending-up.js [app-ssr] (ecmascript) <export default as TrendingUp>");
var __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$scale$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Scale$3e$__ = __turbopack_context__.i("[project]/v1-templates/multi-biz-calculator/node_modules/lucide-react/dist/esm/icons/scale.js [app-ssr] (ecmascript) <export default as Scale>");
var __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plane$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Plane$3e$__ = __turbopack_context__.i("[project]/v1-templates/multi-biz-calculator/node_modules/lucide-react/dist/esm/icons/plane.js [app-ssr] (ecmascript) <export default as Plane>");
var __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$dollar$2d$sign$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__DollarSign$3e$__ = __turbopack_context__.i("[project]/v1-templates/multi-biz-calculator/node_modules/lucide-react/dist/esm/icons/dollar-sign.js [app-ssr] (ecmascript) <export default as DollarSign>");
var __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$gem$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Gem$3e$__ = __turbopack_context__.i("[project]/v1-templates/multi-biz-calculator/node_modules/lucide-react/dist/esm/icons/gem.js [app-ssr] (ecmascript) <export default as Gem>");
var __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$tag$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Tag$3e$__ = __turbopack_context__.i("[project]/v1-templates/multi-biz-calculator/node_modules/lucide-react/dist/esm/icons/tag.js [app-ssr] (ecmascript) <export default as Tag>");
"use client";
;
;
;
function BusinessCalculators() {
    const [activeTab, setActiveTab] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("profit-margin");
    const tabs = [
        {
            id: "profit-margin",
            label: "Profit Margin",
            Icon: __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trending$2d$up$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__TrendingUp$3e$__["TrendingUp"]
        },
        {
            id: "break-even",
            label: "Break-Even",
            Icon: __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$scale$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Scale$3e$__["Scale"]
        },
        {
            id: "runway",
            label: "Runway",
            Icon: __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plane$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Plane$3e$__["Plane"]
        },
        {
            id: "cash-flow",
            label: "Cash Flow",
            Icon: __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$dollar$2d$sign$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__DollarSign$3e$__["DollarSign"]
        },
        {
            id: "valuation",
            label: "Valuation",
            Icon: __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$gem$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Gem$3e$__["Gem"]
        },
        {
            id: "pricing",
            label: "Pricing",
            Icon: __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$tag$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Tag$3e$__["Tag"]
        }
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "max-w-5xl mx-auto p-4 sm:p-6",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-white rounded-lg shadow-sm border border-gray-200 mb-6 overflow-x-auto",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex min-w-max sm:min-w-0",
                    children: tabs.map((tab)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: ()=>setActiveTab(tab.id),
                            className: `flex-1 px-3 sm:px-6 py-3 sm:py-4 text-xs sm:text-sm font-medium transition-colors whitespace-nowrap flex items-center justify-center gap-2 ${activeTab === tab.id ? "bg-blue-50 text-blue-700 border-b-2 border-blue-700" : "text-gray-600 hover:text-gray-900 hover:bg-gray-50"}`,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(tab.Icon, {
                                    className: "w-4 h-4"
                                }, void 0, false, {
                                    fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                    lineNumber: 41,
                                    columnNumber: 15
                                }, this),
                                tab.label
                            ]
                        }, tab.id, true, {
                            fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                            lineNumber: 32,
                            columnNumber: 13
                        }, this))
                }, void 0, false, {
                    fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                    lineNumber: 30,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                lineNumber: 29,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-white rounded-lg shadow-sm border border-gray-200 p-4 sm:p-6",
                children: [
                    activeTab === "profit-margin" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(ProfitMarginCalculator, {}, void 0, false, {
                        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                        lineNumber: 50,
                        columnNumber: 43
                    }, this),
                    activeTab === "break-even" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(BreakEvenCalculator, {}, void 0, false, {
                        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                        lineNumber: 51,
                        columnNumber: 40
                    }, this),
                    activeTab === "runway" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(RunwayCalculator, {}, void 0, false, {
                        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                        lineNumber: 52,
                        columnNumber: 36
                    }, this),
                    activeTab === "cash-flow" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(CashFlowCalculator, {}, void 0, false, {
                        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                        lineNumber: 53,
                        columnNumber: 39
                    }, this),
                    activeTab === "valuation" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(ValuationCalculator, {}, void 0, false, {
                        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                        lineNumber: 54,
                        columnNumber: 39
                    }, this),
                    activeTab === "pricing" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(PricingCalculator, {}, void 0, false, {
                        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                        lineNumber: 55,
                        columnNumber: 37
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                lineNumber: 49,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
        lineNumber: 27,
        columnNumber: 5
    }, this);
}
// Profit Margin Calculator
function ProfitMarginCalculator() {
    const [revenue, setRevenue] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [cogs, setCogs] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [expenses, setExpenses] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const rev = parseFloat(revenue) || 0;
    const costs = parseFloat(cogs) || 0;
    const exp = parseFloat(expenses) || 0;
    const grossProfit = rev - costs;
    const grossMargin = rev > 0 ? grossProfit / rev * 100 : 0;
    const netProfit = grossProfit - exp;
    const netMargin = rev > 0 ? netProfit / rev * 100 : 0;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-6",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: "text-xl font-semibold text-gray-900",
                children: "Profit Margin Calculator"
            }, void 0, false, {
                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                lineNumber: 78,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid grid-cols-1 sm:grid-cols-3 gap-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: "block text-sm font-medium text-gray-700 mb-2",
                                children: "Revenue ($)"
                            }, void 0, false, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 82,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "number",
                                value: revenue,
                                onChange: (e)=>setRevenue(e.target.value),
                                className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent",
                                placeholder: "0.00"
                            }, void 0, false, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 85,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                        lineNumber: 81,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: "block text-sm font-medium text-gray-700 mb-2",
                                children: "Cost of Goods Sold ($)"
                            }, void 0, false, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 95,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "number",
                                value: cogs,
                                onChange: (e)=>setCogs(e.target.value),
                                className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent",
                                placeholder: "0.00"
                            }, void 0, false, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 98,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                        lineNumber: 94,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: "block text-sm font-medium text-gray-700 mb-2",
                                children: "Operating Expenses ($)"
                            }, void 0, false, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 108,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "number",
                                value: expenses,
                                onChange: (e)=>setExpenses(e.target.value),
                                className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent",
                                placeholder: "0.00"
                            }, void 0, false, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 111,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                        lineNumber: 107,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                lineNumber: 80,
                columnNumber: 7
            }, this),
            rev > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid grid-cols-1 sm:grid-cols-2 gap-4 mt-6",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "bg-blue-50 rounded-lg p-4 border border-blue-200",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-sm font-medium text-blue-900 mb-1",
                                children: "Gross Profit Margin"
                            }, void 0, false, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 124,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-3xl font-bold text-blue-700",
                                children: [
                                    grossMargin.toFixed(1),
                                    "%"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 125,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-sm text-blue-600 mt-1",
                                children: [
                                    "$",
                                    grossProfit.toLocaleString(undefined, {
                                        minimumFractionDigits: 2,
                                        maximumFractionDigits: 2
                                    }),
                                    " gross profit"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 126,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                        lineNumber: 123,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: `rounded-lg p-4 border ${netProfit >= 0 ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200'}`,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: `text-sm font-medium mb-1 ${netProfit >= 0 ? 'text-green-900' : 'text-red-900'}`,
                                children: "Net Profit Margin"
                            }, void 0, false, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 132,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: `text-3xl font-bold ${netProfit >= 0 ? 'text-green-700' : 'text-red-700'}`,
                                children: [
                                    netMargin.toFixed(1),
                                    "%"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 135,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: `text-sm mt-1 ${netProfit >= 0 ? 'text-green-600' : 'text-red-600'}`,
                                children: [
                                    "$",
                                    netProfit.toLocaleString(undefined, {
                                        minimumFractionDigits: 2,
                                        maximumFractionDigits: 2
                                    }),
                                    " net profit"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 138,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                        lineNumber: 131,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                lineNumber: 122,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
        lineNumber: 77,
        columnNumber: 5
    }, this);
}
// Break-Even Calculator
function BreakEvenCalculator() {
    const [fixedCosts, setFixedCosts] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [pricePerUnit, setPricePerUnit] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [variableCostPerUnit, setVariableCostPerUnit] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const fixed = parseFloat(fixedCosts) || 0;
    const price = parseFloat(pricePerUnit) || 0;
    const variable = parseFloat(variableCostPerUnit) || 0;
    const contributionMargin = price - variable;
    const breakEvenUnits = contributionMargin > 0 ? fixed / contributionMargin : 0;
    const breakEvenRevenue = breakEvenUnits * price;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-6",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: "text-xl font-semibold text-gray-900",
                children: "Break-Even Point Calculator"
            }, void 0, false, {
                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                lineNumber: 164,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-sm text-gray-600",
                children: "Calculate when your business becomes profitable"
            }, void 0, false, {
                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                lineNumber: 165,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid grid-cols-1 sm:grid-cols-3 gap-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: "block text-sm font-medium text-gray-700 mb-2",
                                children: "Fixed Costs ($)"
                            }, void 0, false, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 169,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "number",
                                value: fixedCosts,
                                onChange: (e)=>setFixedCosts(e.target.value),
                                className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent",
                                placeholder: "0.00"
                            }, void 0, false, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 172,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-xs text-gray-500 mt-1",
                                children: "Rent, salaries, insurance"
                            }, void 0, false, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 179,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                        lineNumber: 168,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: "block text-sm font-medium text-gray-700 mb-2",
                                children: "Price per Unit ($)"
                            }, void 0, false, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 183,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "number",
                                value: pricePerUnit,
                                onChange: (e)=>setPricePerUnit(e.target.value),
                                className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent",
                                placeholder: "0.00"
                            }, void 0, false, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 186,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-xs text-gray-500 mt-1",
                                children: "Selling price"
                            }, void 0, false, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 193,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                        lineNumber: 182,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: "block text-sm font-medium text-gray-700 mb-2",
                                children: "Variable Cost per Unit ($)"
                            }, void 0, false, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 197,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "number",
                                value: variableCostPerUnit,
                                onChange: (e)=>setVariableCostPerUnit(e.target.value),
                                className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent",
                                placeholder: "0.00"
                            }, void 0, false, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 200,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-xs text-gray-500 mt-1",
                                children: "Materials, labor per unit"
                            }, void 0, false, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 207,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                        lineNumber: 196,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                lineNumber: 167,
                columnNumber: 7
            }, this),
            contributionMargin > 0 && breakEvenUnits > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid grid-cols-1 sm:grid-cols-3 gap-4 mt-6",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "bg-purple-50 rounded-lg p-4 border border-purple-200",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-sm font-medium text-purple-900 mb-1",
                                children: "Break-Even Units"
                            }, void 0, false, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 214,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-3xl font-bold text-purple-700",
                                children: Math.ceil(breakEvenUnits).toLocaleString()
                            }, void 0, false, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 215,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-sm text-purple-600 mt-1",
                                children: "units to sell"
                            }, void 0, false, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 218,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                        lineNumber: 213,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "bg-purple-50 rounded-lg p-4 border border-purple-200",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-sm font-medium text-purple-900 mb-1",
                                children: "Break-Even Revenue"
                            }, void 0, false, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 222,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-3xl font-bold text-purple-700",
                                children: [
                                    "$",
                                    breakEvenRevenue.toLocaleString(undefined, {
                                        minimumFractionDigits: 0,
                                        maximumFractionDigits: 0
                                    })
                                ]
                            }, void 0, true, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 223,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-sm text-purple-600 mt-1",
                                children: "to be profitable"
                            }, void 0, false, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 226,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                        lineNumber: 221,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "bg-purple-50 rounded-lg p-4 border border-purple-200",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-sm font-medium text-purple-900 mb-1",
                                children: "Contribution Margin"
                            }, void 0, false, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 230,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-3xl font-bold text-purple-700",
                                children: [
                                    "$",
                                    contributionMargin.toFixed(2)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 231,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-sm text-purple-600 mt-1",
                                children: "per unit sold"
                            }, void 0, false, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 234,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                        lineNumber: 229,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                lineNumber: 212,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
        lineNumber: 163,
        columnNumber: 5
    }, this);
}
// Runway Calculator
function RunwayCalculator() {
    const [cashBalance, setCashBalance] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [monthlyBurn, setMonthlyBurn] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [monthlyRevenue, setMonthlyRevenue] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const balance = parseFloat(cashBalance) || 0;
    const burn = parseFloat(monthlyBurn) || 0;
    const revenue = parseFloat(monthlyRevenue) || 0;
    const netBurn = burn - revenue;
    const runwayMonths = netBurn > 0 ? balance / netBurn : 0;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-6",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: "text-xl font-semibold text-gray-900",
                children: "Runway Calculator"
            }, void 0, false, {
                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                lineNumber: 257,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-sm text-gray-600",
                children: "How long until you run out of money?"
            }, void 0, false, {
                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                lineNumber: 258,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid grid-cols-1 sm:grid-cols-3 gap-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: "block text-sm font-medium text-gray-700 mb-2",
                                children: "Current Cash Balance ($)"
                            }, void 0, false, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 262,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "number",
                                value: cashBalance,
                                onChange: (e)=>setCashBalance(e.target.value),
                                className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent",
                                placeholder: "0.00"
                            }, void 0, false, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 265,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                        lineNumber: 261,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: "block text-sm font-medium text-gray-700 mb-2",
                                children: "Monthly Burn Rate ($)"
                            }, void 0, false, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 275,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "number",
                                value: monthlyBurn,
                                onChange: (e)=>setMonthlyBurn(e.target.value),
                                className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent",
                                placeholder: "0.00"
                            }, void 0, false, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 278,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-xs text-gray-500 mt-1",
                                children: "Monthly expenses"
                            }, void 0, false, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 285,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                        lineNumber: 274,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: "block text-sm font-medium text-gray-700 mb-2",
                                children: "Monthly Revenue ($)"
                            }, void 0, false, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 289,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "number",
                                value: monthlyRevenue,
                                onChange: (e)=>setMonthlyRevenue(e.target.value),
                                className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent",
                                placeholder: "0.00"
                            }, void 0, false, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 292,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                        lineNumber: 288,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                lineNumber: 260,
                columnNumber: 7
            }, this),
            balance > 0 && netBurn > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid grid-cols-1 sm:grid-cols-2 gap-4 mt-6",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: `rounded-lg p-4 border ${runwayMonths > 12 ? 'bg-green-50 border-green-200' : runwayMonths > 6 ? 'bg-yellow-50 border-yellow-200' : 'bg-red-50 border-red-200'}`,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: `text-sm font-medium mb-1 ${runwayMonths > 12 ? 'text-green-900' : runwayMonths > 6 ? 'text-yellow-900' : 'text-red-900'}`,
                                children: "Runway"
                            }, void 0, false, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 309,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: `text-3xl font-bold ${runwayMonths > 12 ? 'text-green-700' : runwayMonths > 6 ? 'text-yellow-700' : 'text-red-700'}`,
                                children: [
                                    runwayMonths.toFixed(1),
                                    " months"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 316,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: `text-sm mt-1 ${runwayMonths > 12 ? 'text-green-600' : runwayMonths > 6 ? 'text-yellow-600' : 'text-red-600'}`,
                                children: runwayMonths > 12 ? 'Healthy runway' : runwayMonths > 6 ? 'Consider fundraising' : 'Critical - act now!'
                            }, void 0, false, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 323,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                        lineNumber: 304,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "bg-gray-50 rounded-lg p-4 border border-gray-200",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-sm font-medium text-gray-900 mb-1",
                                children: "Net Monthly Burn"
                            }, void 0, false, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 333,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-3xl font-bold text-gray-700",
                                children: [
                                    "$",
                                    netBurn.toLocaleString(undefined, {
                                        minimumFractionDigits: 0,
                                        maximumFractionDigits: 0
                                    })
                                ]
                            }, void 0, true, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 334,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-sm text-gray-600 mt-1",
                                children: "After revenue"
                            }, void 0, false, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 337,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                        lineNumber: 332,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                lineNumber: 303,
                columnNumber: 9
            }, this),
            netBurn <= 0 && revenue > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-green-50 rounded-lg p-4 border border-green-200 mt-6",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-green-900 font-medium",
                        children: "Cash Flow Positive!"
                    }, void 0, false, {
                        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                        lineNumber: 346,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-sm text-green-700 mt-1",
                        children: "Your revenue exceeds your burn rate. Keep it up!"
                    }, void 0, false, {
                        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                        lineNumber: 347,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                lineNumber: 345,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
        lineNumber: 256,
        columnNumber: 5
    }, this);
}
// Cash Flow Projector
function CashFlowCalculator() {
    const [startingCash, setStartingCash] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [monthlyRevenue, setMonthlyRevenue] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [monthlyExpenses, setMonthlyExpenses] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [growthRate, setGrowthRate] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("0");
    const starting = parseFloat(startingCash) || 0;
    const revenue = parseFloat(monthlyRevenue) || 0;
    const expenses = parseFloat(monthlyExpenses) || 0;
    const growth = parseFloat(growthRate) || 0;
    const projections = [];
    let currentCash = starting;
    let currentRevenue = revenue;
    for(let month = 1; month <= 12; month++){
        const netCashFlow = currentRevenue - expenses;
        currentCash += netCashFlow;
        projections.push({
            month,
            revenue: currentRevenue,
            expenses,
            netCashFlow,
            endingBalance: currentCash
        });
        currentRevenue *= 1 + growth / 100;
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-6",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: "text-xl font-semibold text-gray-900",
                children: "Cash Flow Projector"
            }, void 0, false, {
                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                lineNumber: 389,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-sm text-gray-600",
                children: "12-month cash flow projection"
            }, void 0, false, {
                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                lineNumber: 390,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid grid-cols-1 sm:grid-cols-4 gap-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: "block text-sm font-medium text-gray-700 mb-2",
                                children: "Starting Cash ($)"
                            }, void 0, false, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 394,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "number",
                                value: startingCash,
                                onChange: (e)=>setStartingCash(e.target.value),
                                className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent",
                                placeholder: "0.00"
                            }, void 0, false, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 397,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                        lineNumber: 393,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: "block text-sm font-medium text-gray-700 mb-2",
                                children: "Monthly Revenue ($)"
                            }, void 0, false, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 407,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "number",
                                value: monthlyRevenue,
                                onChange: (e)=>setMonthlyRevenue(e.target.value),
                                className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent",
                                placeholder: "0.00"
                            }, void 0, false, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 410,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                        lineNumber: 406,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: "block text-sm font-medium text-gray-700 mb-2",
                                children: "Monthly Expenses ($)"
                            }, void 0, false, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 420,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "number",
                                value: monthlyExpenses,
                                onChange: (e)=>setMonthlyExpenses(e.target.value),
                                className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent",
                                placeholder: "0.00"
                            }, void 0, false, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 423,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                        lineNumber: 419,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: "block text-sm font-medium text-gray-700 mb-2",
                                children: "Monthly Growth (%)"
                            }, void 0, false, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 433,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "number",
                                value: growthRate,
                                onChange: (e)=>setGrowthRate(e.target.value),
                                className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent",
                                placeholder: "0",
                                step: "0.1"
                            }, void 0, false, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 436,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                        lineNumber: 432,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                lineNumber: 392,
                columnNumber: 7
            }, this),
            starting > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-6 overflow-x-auto",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
                    className: "w-full text-sm",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("thead", {
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                className: "border-b border-gray-200 bg-gray-50",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                        className: "text-left py-3 px-4 font-medium text-gray-700",
                                        children: "Month"
                                    }, void 0, false, {
                                        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                        lineNumber: 452,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                        className: "text-right py-3 px-4 font-medium text-gray-700",
                                        children: "Revenue"
                                    }, void 0, false, {
                                        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                        lineNumber: 453,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                        className: "text-right py-3 px-4 font-medium text-gray-700",
                                        children: "Expenses"
                                    }, void 0, false, {
                                        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                        lineNumber: 454,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                        className: "text-right py-3 px-4 font-medium text-gray-700",
                                        children: "Net Cash Flow"
                                    }, void 0, false, {
                                        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                        lineNumber: 455,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                        className: "text-right py-3 px-4 font-medium text-gray-700",
                                        children: "Ending Balance"
                                    }, void 0, false, {
                                        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                        lineNumber: 456,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 451,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                            lineNumber: 450,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("tbody", {
                            children: projections.map((p)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                    className: "border-b border-gray-100 hover:bg-gray-50",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                            className: "py-3 px-4 font-medium text-gray-900",
                                            children: [
                                                "Month ",
                                                p.month
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                            lineNumber: 462,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                            className: "py-3 px-4 text-right text-gray-700",
                                            children: [
                                                "$",
                                                p.revenue.toLocaleString(undefined, {
                                                    minimumFractionDigits: 0,
                                                    maximumFractionDigits: 0
                                                })
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                            lineNumber: 463,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                            className: "py-3 px-4 text-right text-gray-700",
                                            children: [
                                                "$",
                                                p.expenses.toLocaleString(undefined, {
                                                    minimumFractionDigits: 0,
                                                    maximumFractionDigits: 0
                                                })
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                            lineNumber: 466,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                            className: `py-3 px-4 text-right font-medium ${p.netCashFlow >= 0 ? 'text-green-600' : 'text-red-600'}`,
                                            children: [
                                                "$",
                                                p.netCashFlow.toLocaleString(undefined, {
                                                    minimumFractionDigits: 0,
                                                    maximumFractionDigits: 0
                                                })
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                            lineNumber: 469,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                            className: `py-3 px-4 text-right font-medium ${p.endingBalance >= 0 ? 'text-gray-900' : 'text-red-600'}`,
                                            children: [
                                                "$",
                                                p.endingBalance.toLocaleString(undefined, {
                                                    minimumFractionDigits: 0,
                                                    maximumFractionDigits: 0
                                                })
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                            lineNumber: 472,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, p.month, true, {
                                    fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                    lineNumber: 461,
                                    columnNumber: 17
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                            lineNumber: 459,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                    lineNumber: 449,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                lineNumber: 448,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
        lineNumber: 388,
        columnNumber: 5
    }, this);
}
// Business Valuation Estimator
function ValuationCalculator() {
    const [annualRevenue, setAnnualRevenue] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [annualProfit, setAnnualProfit] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [growthRate, setGrowthRate] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [industry, setIndustry] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("saas");
    const revenue = parseFloat(annualRevenue) || 0;
    const profit = parseFloat(annualProfit) || 0;
    const growth = parseFloat(growthRate) || 0;
    // Industry-specific multiples
    const multiples = {
        saas: {
            revenue: 8,
            profit: 15
        },
        ecommerce: {
            revenue: 1.5,
            profit: 3
        },
        service: {
            revenue: 1,
            profit: 3
        },
        manufacturing: {
            revenue: 0.75,
            profit: 4
        },
        retail: {
            revenue: 0.5,
            profit: 2.5
        }
    };
    const multiple = multiples[industry];
    const baseRevenueValuation = revenue * multiple.revenue;
    const baseProfitValuation = profit * multiple.profit;
    // Growth adjustment (add 0-50% based on growth rate)
    const growthMultiplier = 1 + Math.min(growth / 100, 0.5);
    const revenueValuation = baseRevenueValuation * growthMultiplier;
    const profitValuation = baseProfitValuation * growthMultiplier;
    const averageValuation = (revenueValuation + profitValuation) / 2;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-6",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: "text-xl font-semibold text-gray-900",
                children: "Business Valuation Estimator"
            }, void 0, false, {
                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                lineNumber: 517,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-sm text-gray-600",
                children: "Estimate your company's worth using industry multiples"
            }, void 0, false, {
                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                lineNumber: 518,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: "block text-sm font-medium text-gray-700 mb-2",
                                children: "Annual Revenue ($)"
                            }, void 0, false, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 522,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "number",
                                value: annualRevenue,
                                onChange: (e)=>setAnnualRevenue(e.target.value),
                                className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent",
                                placeholder: "0.00"
                            }, void 0, false, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 525,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                        lineNumber: 521,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: "block text-sm font-medium text-gray-700 mb-2",
                                children: "Annual Net Profit ($)"
                            }, void 0, false, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 535,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "number",
                                value: annualProfit,
                                onChange: (e)=>setAnnualProfit(e.target.value),
                                className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent",
                                placeholder: "0.00"
                            }, void 0, false, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 538,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                        lineNumber: 534,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: "block text-sm font-medium text-gray-700 mb-2",
                                children: "Industry"
                            }, void 0, false, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 548,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                value: industry,
                                onChange: (e)=>setIndustry(e.target.value),
                                className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: "saas",
                                        children: "SaaS (Software)"
                                    }, void 0, false, {
                                        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                        lineNumber: 556,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: "ecommerce",
                                        children: "E-commerce"
                                    }, void 0, false, {
                                        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                        lineNumber: 557,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: "service",
                                        children: "Service Business"
                                    }, void 0, false, {
                                        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                        lineNumber: 558,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: "manufacturing",
                                        children: "Manufacturing"
                                    }, void 0, false, {
                                        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                        lineNumber: 559,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: "retail",
                                        children: "Retail"
                                    }, void 0, false, {
                                        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                        lineNumber: 560,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 551,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                        lineNumber: 547,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: "block text-sm font-medium text-gray-700 mb-2",
                                children: "YoY Growth Rate (%)"
                            }, void 0, false, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 565,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "number",
                                value: growthRate,
                                onChange: (e)=>setGrowthRate(e.target.value),
                                className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent",
                                placeholder: "0"
                            }, void 0, false, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 568,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                        lineNumber: 564,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                lineNumber: 520,
                columnNumber: 7
            }, this),
            revenue > 0 && profit > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-4 mt-6",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg p-6 border border-blue-200",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-sm font-medium text-gray-900 mb-2",
                                children: "Estimated Valuation Range"
                            }, void 0, false, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 581,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-4xl font-bold text-gray-900 mb-2",
                                children: [
                                    "$",
                                    Math.min(revenueValuation, profitValuation).toLocaleString(undefined, {
                                        minimumFractionDigits: 0,
                                        maximumFractionDigits: 0
                                    }),
                                    ' - ',
                                    "$",
                                    Math.max(revenueValuation, profitValuation).toLocaleString(undefined, {
                                        minimumFractionDigits: 0,
                                        maximumFractionDigits: 0
                                    })
                                ]
                            }, void 0, true, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 582,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-sm text-gray-600",
                                children: [
                                    "Average: $",
                                    averageValuation.toLocaleString(undefined, {
                                        minimumFractionDigits: 0,
                                        maximumFractionDigits: 0
                                    })
                                ]
                            }, void 0, true, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 587,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                        lineNumber: 580,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "bg-white rounded-lg p-4 border border-gray-200",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "text-sm font-medium text-gray-700 mb-1",
                                        children: "Revenue Multiple"
                                    }, void 0, false, {
                                        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                        lineNumber: 594,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "text-2xl font-bold text-gray-900",
                                        children: [
                                            multiple.revenue,
                                            "x"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                        lineNumber: 595,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "text-sm text-gray-600 mt-1",
                                        children: [
                                            "Valuation: $",
                                            revenueValuation.toLocaleString(undefined, {
                                                minimumFractionDigits: 0,
                                                maximumFractionDigits: 0
                                            })
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                        lineNumber: 598,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 593,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "bg-white rounded-lg p-4 border border-gray-200",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "text-sm font-medium text-gray-700 mb-1",
                                        children: "Profit Multiple (EBITDA)"
                                    }, void 0, false, {
                                        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                        lineNumber: 604,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "text-2xl font-bold text-gray-900",
                                        children: [
                                            multiple.profit,
                                            "x"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                        lineNumber: 605,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "text-sm text-gray-600 mt-1",
                                        children: [
                                            "Valuation: $",
                                            profitValuation.toLocaleString(undefined, {
                                                minimumFractionDigits: 0,
                                                maximumFractionDigits: 0
                                            })
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                        lineNumber: 608,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 603,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                        lineNumber: 592,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "bg-blue-50 rounded-lg p-4 border border-blue-200 text-sm text-blue-900",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                children: "Note:"
                            }, void 0, false, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 615,
                                columnNumber: 13
                            }, this),
                            " This is a simplified estimate. Actual valuations depend on many factors including market conditions, assets, competitive advantages, customer retention, and more. Consult a professional for accurate valuation."
                        ]
                    }, void 0, true, {
                        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                        lineNumber: 614,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                lineNumber: 579,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
        lineNumber: 516,
        columnNumber: 5
    }, this);
}
// Pricing Strategy Calculator
function PricingCalculator() {
    const [costPerUnit, setCostPerUnit] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [desiredMargin, setDesiredMargin] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("40");
    const [monthlyVolume, setMonthlyVolume] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [competitorPrice, setCompetitorPrice] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const cost = parseFloat(costPerUnit) || 0;
    const margin = parseFloat(desiredMargin) || 0;
    const volume = parseFloat(monthlyVolume) || 0;
    const competitor = parseFloat(competitorPrice) || 0;
    // Cost-plus pricing
    const costPlusPrice = cost > 0 ? cost / (1 - margin / 100) : 0;
    // Value-based pricing (assuming competitor pricing is market value)
    const valuePriceDiscount = competitor * 0.9; // 10% below competitor
    const valuePriceMatch = competitor;
    const valuePricePremium = competitor * 1.1; // 10% above competitor
    const monthlyRevenueCostPlus = costPlusPrice * volume;
    const monthlyProfitCostPlus = (costPlusPrice - cost) * volume;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-6",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: "text-xl font-semibold text-gray-900",
                children: "Pricing Strategy Calculator"
            }, void 0, false, {
                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                lineNumber: 648,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-sm text-gray-600",
                children: "Find the optimal price for your product or service"
            }, void 0, false, {
                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                lineNumber: 649,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: "block text-sm font-medium text-gray-700 mb-2",
                                children: "Cost per Unit ($)"
                            }, void 0, false, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 653,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "number",
                                value: costPerUnit,
                                onChange: (e)=>setCostPerUnit(e.target.value),
                                className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent",
                                placeholder: "0.00"
                            }, void 0, false, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 656,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-xs text-gray-500 mt-1",
                                children: "Total cost to produce/deliver"
                            }, void 0, false, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 663,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                        lineNumber: 652,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: "block text-sm font-medium text-gray-700 mb-2",
                                children: "Desired Margin (%)"
                            }, void 0, false, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 667,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "number",
                                value: desiredMargin,
                                onChange: (e)=>setDesiredMargin(e.target.value),
                                className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent",
                                placeholder: "40"
                            }, void 0, false, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 670,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                        lineNumber: 666,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: "block text-sm font-medium text-gray-700 mb-2",
                                children: "Expected Monthly Volume"
                            }, void 0, false, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 680,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "number",
                                value: monthlyVolume,
                                onChange: (e)=>setMonthlyVolume(e.target.value),
                                className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent",
                                placeholder: "0"
                            }, void 0, false, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 683,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                        lineNumber: 679,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: "block text-sm font-medium text-gray-700 mb-2",
                                children: "Competitor Price ($)"
                            }, void 0, false, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 693,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "number",
                                value: competitorPrice,
                                onChange: (e)=>setCompetitorPrice(e.target.value),
                                className: "w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent",
                                placeholder: "0.00"
                            }, void 0, false, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 696,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-xs text-gray-500 mt-1",
                                children: "Optional: for comparison"
                            }, void 0, false, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 703,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                        lineNumber: 692,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                lineNumber: 651,
                columnNumber: 7
            }, this),
            cost > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-4 mt-6",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                className: "text-lg font-semibold text-gray-900 mb-3",
                                children: "Cost-Plus Pricing"
                            }, void 0, false, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 710,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "bg-blue-50 rounded-lg p-6 border border-blue-200",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "text-sm font-medium text-blue-900 mb-2",
                                        children: "Recommended Price"
                                    }, void 0, false, {
                                        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                        lineNumber: 712,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "text-4xl font-bold text-blue-700 mb-4",
                                        children: [
                                            "$",
                                            costPlusPrice.toFixed(2)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                        lineNumber: 713,
                                        columnNumber: 15
                                    }, this),
                                    volume > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "grid grid-cols-2 gap-4 text-sm",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "text-blue-900 font-medium",
                                                        children: "Monthly Revenue"
                                                    }, void 0, false, {
                                                        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                                        lineNumber: 720,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "text-blue-700 text-lg font-semibold",
                                                        children: [
                                                            "$",
                                                            monthlyRevenueCostPlus.toLocaleString(undefined, {
                                                                minimumFractionDigits: 0,
                                                                maximumFractionDigits: 0
                                                            })
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                                        lineNumber: 721,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                                lineNumber: 719,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "text-blue-900 font-medium",
                                                        children: "Monthly Profit"
                                                    }, void 0, false, {
                                                        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                                        lineNumber: 726,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "text-blue-700 text-lg font-semibold",
                                                        children: [
                                                            "$",
                                                            monthlyProfitCostPlus.toLocaleString(undefined, {
                                                                minimumFractionDigits: 0,
                                                                maximumFractionDigits: 0
                                                            })
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                                        lineNumber: 727,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                                lineNumber: 725,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                        lineNumber: 718,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 711,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                        lineNumber: 709,
                        columnNumber: 11
                    }, this),
                    competitor > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                className: "text-lg font-semibold text-gray-900 mb-3",
                                children: "Competitive Pricing Strategies"
                            }, void 0, false, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 738,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "grid grid-cols-1 sm:grid-cols-3 gap-4",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "bg-white rounded-lg p-4 border border-gray-200",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "text-sm font-medium text-gray-900 mb-2",
                                                children: "Penetration (Discount)"
                                            }, void 0, false, {
                                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                                lineNumber: 741,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "text-2xl font-bold text-orange-600 mb-1",
                                                children: [
                                                    "$",
                                                    valuePriceDiscount.toFixed(2)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                                lineNumber: 742,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "text-xs text-gray-600 mb-2",
                                                children: "10% below competitor"
                                            }, void 0, false, {
                                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                                lineNumber: 745,
                                                columnNumber: 19
                                            }, this),
                                            cost > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "text-sm text-gray-700",
                                                children: [
                                                    "Margin: ",
                                                    ((valuePriceDiscount - cost) / valuePriceDiscount * 100).toFixed(1),
                                                    "%"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                                lineNumber: 747,
                                                columnNumber: 21
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                        lineNumber: 740,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "bg-white rounded-lg p-4 border border-gray-200",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "text-sm font-medium text-gray-900 mb-2",
                                                children: "Match Market"
                                            }, void 0, false, {
                                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                                lineNumber: 754,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "text-2xl font-bold text-blue-600 mb-1",
                                                children: [
                                                    "$",
                                                    valuePriceMatch.toFixed(2)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                                lineNumber: 755,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "text-xs text-gray-600 mb-2",
                                                children: "Same as competitor"
                                            }, void 0, false, {
                                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                                lineNumber: 758,
                                                columnNumber: 19
                                            }, this),
                                            cost > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "text-sm text-gray-700",
                                                children: [
                                                    "Margin: ",
                                                    ((valuePriceMatch - cost) / valuePriceMatch * 100).toFixed(1),
                                                    "%"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                                lineNumber: 760,
                                                columnNumber: 21
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                        lineNumber: 753,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "bg-white rounded-lg p-4 border border-gray-200",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "text-sm font-medium text-gray-900 mb-2",
                                                children: "Premium"
                                            }, void 0, false, {
                                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                                lineNumber: 767,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "text-2xl font-bold text-purple-600 mb-1",
                                                children: [
                                                    "$",
                                                    valuePricePremium.toFixed(2)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                                lineNumber: 768,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "text-xs text-gray-600 mb-2",
                                                children: "10% above competitor"
                                            }, void 0, false, {
                                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                                lineNumber: 771,
                                                columnNumber: 19
                                            }, this),
                                            cost > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "text-sm text-gray-700",
                                                children: [
                                                    "Margin: ",
                                                    ((valuePricePremium - cost) / valuePricePremium * 100).toFixed(1),
                                                    "%"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                                lineNumber: 773,
                                                columnNumber: 21
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                        lineNumber: 766,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 739,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                        lineNumber: 737,
                        columnNumber: 13
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "bg-yellow-50 rounded-lg p-4 border border-yellow-200 text-sm text-yellow-900",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                children: "Tips:"
                            }, void 0, false, {
                                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                                lineNumber: 783,
                                columnNumber: 13
                            }, this),
                            " Consider your value proposition, target market, and brand positioning. Premium pricing works with strong differentiation. Penetration pricing helps gain market share quickly."
                        ]
                    }, void 0, true, {
                        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                        lineNumber: 782,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
                lineNumber: 708,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/v1-templates/multi-biz-calculator/app/components/BusinessCalculators.tsx",
        lineNumber: 647,
        columnNumber: 5
    }, this);
}
}),
];

//# sourceMappingURL=00aa7_multi-biz-calculator_app_components_BusinessCalculators_tsx_943544c7._.js.map