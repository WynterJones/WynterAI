module.exports = [
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[project]/v1-templates/multi-biz-calculator/app/hooks/useIframeResize.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useIframeResize",
    ()=>useIframeResize
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/v1-templates/multi-biz-calculator/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
;
function useIframeResize() {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (window.self === window.top) {
            return;
        }
        function sendHeight() {
            const height = document.body.scrollHeight;
            window.parent.postMessage({
                type: "iframe-resize",
                height: height
            }, "*");
        }
        sendHeight();
        const resizeObserver = new ResizeObserver(()=>{
            sendHeight();
        });
        resizeObserver.observe(document.body);
        const mutationObserver = new MutationObserver(()=>{
            sendHeight();
        });
        mutationObserver.observe(document.body, {
            childList: true,
            subtree: true,
            attributes: true
        });
        window.addEventListener("resize", sendHeight);
        return ()=>{
            resizeObserver.disconnect();
            mutationObserver.disconnect();
            window.removeEventListener("resize", sendHeight);
        };
    }, []);
}
}),
"[project]/v1-templates/multi-biz-calculator/app/components/IframeResizeProvider.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "IframeResizeProvider",
    ()=>IframeResizeProvider
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$app$2f$hooks$2f$useIframeResize$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/v1-templates/multi-biz-calculator/app/hooks/useIframeResize.ts [app-ssr] (ecmascript)");
'use client';
;
function IframeResizeProvider() {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$app$2f$hooks$2f$useIframeResize$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useIframeResize"])();
    return null;
}
}),
"[project]/v1-templates/multi-biz-calculator/node_modules/next/dist/server/route-modules/app-page/module.compiled.js [app-ssr] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
;
else {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    else {
        if ("TURBOPACK compile-time truthy", 1) {
            if ("TURBOPACK compile-time truthy", 1) {
                module.exports = __turbopack_context__.r("[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)");
            } else //TURBOPACK unreachable
            ;
        } else //TURBOPACK unreachable
        ;
    }
} //# sourceMappingURL=module.compiled.js.map
}),
"[project]/v1-templates/multi-biz-calculator/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

module.exports = __turbopack_context__.r("[project]/v1-templates/multi-biz-calculator/node_modules/next/dist/server/route-modules/app-page/module.compiled.js [app-ssr] (ecmascript)").vendored['react-ssr'].React; //# sourceMappingURL=react.js.map
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__65ae4e9e._.js.map