globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/4b750_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_7bb80cee._.js",
    "static/chunks/4b750_next_dist_compiled_react-dom_2733162f._.js",
    "static/chunks/4b750_next_dist_compiled_react-server-dom-turbopack_e60037eb._.js",
    "static/chunks/4b750_next_dist_compiled_next-devtools_index_233bc356.js",
    "static/chunks/4b750_next_dist_compiled_0c242fa8._.js",
    "static/chunks/4b750_next_dist_client_e9480492._.js",
    "static/chunks/4b750_next_dist_ead406cf._.js",
    "static/chunks/4b750_@swc_helpers_cjs_9d4f9f35._.js",
    "static/chunks/v1-templates_multi-biz-calculator_a0ff3932._.js",
    "static/chunks/turbopack-v1-templates_multi-biz-calculator_6403cc99._.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];