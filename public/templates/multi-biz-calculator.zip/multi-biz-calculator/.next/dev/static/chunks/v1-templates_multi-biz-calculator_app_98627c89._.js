(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/v1-templates/multi-biz-calculator/app/hooks/useIframeResize.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useIframeResize",
    ()=>useIframeResize
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/v1-templates/multi-biz-calculator/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
function useIframeResize() {
    _s();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useIframeResize.useEffect": ()=>{
            if (window.self === window.top) {
                return;
            }
            function sendHeight() {
                const height = document.body.scrollHeight;
                window.parent.postMessage({
                    type: "iframe-resize",
                    height: height
                }, "*");
            }
            sendHeight();
            const resizeObserver = new ResizeObserver({
                "useIframeResize.useEffect": ()=>{
                    sendHeight();
                }
            }["useIframeResize.useEffect"]);
            resizeObserver.observe(document.body);
            const mutationObserver = new MutationObserver({
                "useIframeResize.useEffect": ()=>{
                    sendHeight();
                }
            }["useIframeResize.useEffect"]);
            mutationObserver.observe(document.body, {
                childList: true,
                subtree: true,
                attributes: true
            });
            window.addEventListener("resize", sendHeight);
            return ({
                "useIframeResize.useEffect": ()=>{
                    resizeObserver.disconnect();
                    mutationObserver.disconnect();
                    window.removeEventListener("resize", sendHeight);
                }
            })["useIframeResize.useEffect"];
        }
    }["useIframeResize.useEffect"], []);
}
_s(useIframeResize, "OD7bBpZva5O2jO+Puf00hKivP7c=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/v1-templates/multi-biz-calculator/app/components/IframeResizeProvider.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "IframeResizeProvider",
    ()=>IframeResizeProvider
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$app$2f$hooks$2f$useIframeResize$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/v1-templates/multi-biz-calculator/app/hooks/useIframeResize.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
'use client';
;
function IframeResizeProvider() {
    _s();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$app$2f$hooks$2f$useIframeResize$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIframeResize"])();
    return null;
}
_s(IframeResizeProvider, "M3mFxljratsofK3lSwlGrvQg7bI=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$v1$2d$templates$2f$multi$2d$biz$2d$calculator$2f$app$2f$hooks$2f$useIframeResize$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIframeResize"]
    ];
});
_c = IframeResizeProvider;
var _c;
__turbopack_context__.k.register(_c, "IframeResizeProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=v1-templates_multi-biz-calculator_app_98627c89._.js.map