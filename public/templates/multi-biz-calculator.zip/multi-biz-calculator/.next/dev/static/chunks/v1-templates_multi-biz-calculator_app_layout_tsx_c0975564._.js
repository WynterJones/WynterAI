(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__e9a1f3fb._.css",
  "static/chunks/v1-templates_multi-biz-calculator_app_98627c89._.js"
],
    source: "dynamic"
});
