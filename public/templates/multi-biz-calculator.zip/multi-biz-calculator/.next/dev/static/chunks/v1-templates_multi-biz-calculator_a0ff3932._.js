(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_7bb80cee._.js",
  "static/chunks/4b750_next_dist_compiled_react-dom_2733162f._.js",
  "static/chunks/4b750_next_dist_compiled_react-server-dom-turbopack_e60037eb._.js",
  "static/chunks/4b750_next_dist_compiled_next-devtools_index_233bc356.js",
  "static/chunks/4b750_next_dist_compiled_0c242fa8._.js",
  "static/chunks/4b750_next_dist_client_e9480492._.js",
  "static/chunks/4b750_next_dist_ead406cf._.js",
  "static/chunks/4b750_@swc_helpers_cjs_9d4f9f35._.js"
],
    source: "entry"
});
