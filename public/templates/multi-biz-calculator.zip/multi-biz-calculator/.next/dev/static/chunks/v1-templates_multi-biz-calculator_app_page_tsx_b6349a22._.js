(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/00aa7_multi-biz-calculator_app_components_BusinessCalculators_tsx_80bb5fb1._.js",
  "static/chunks/4b750_f6e3c6ea._.js"
],
    source: "dynamic"
});
