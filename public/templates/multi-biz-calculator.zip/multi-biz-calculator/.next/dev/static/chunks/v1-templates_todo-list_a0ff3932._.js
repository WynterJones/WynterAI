(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_ef6e31d7._.js",
  "static/chunks/135a9_next_dist_compiled_react-dom_c037bdec._.js",
  "static/chunks/135a9_next_dist_compiled_react-server-dom-turbopack_c8a16d17._.js",
  "static/chunks/135a9_next_dist_compiled_next-devtools_index_00f562cb.js",
  "static/chunks/135a9_next_dist_compiled_a3cb961a._.js",
  "static/chunks/135a9_next_dist_client_1bbb7d93._.js",
  "static/chunks/135a9_next_dist_be142e56._.js",
  "static/chunks/135a9_@swc_helpers_cjs_536f4afe._.js"
],
    source: "entry"
});
