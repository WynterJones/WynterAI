(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__ba60bd57._.css",
  "static/chunks/v1-templates_todo-list_app_143510d4._.js"
],
    source: "dynamic"
});
